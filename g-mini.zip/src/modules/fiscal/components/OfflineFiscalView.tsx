// OfflineFiscalView.tsx - Robust Offline Fiscal Operations for G-Admin Mini
// Handles invoice generation, tax calculations, and AFIP queue management offline

import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Card,
  VStack,
  HStack,
  Text,
  Badge,
  Button,
  Alert,
  Progress,
  Tabs,
  SimpleGrid,
  Stat,
  Tooltip,
  Switch
} from '@chakra-ui/react';
import {
  DocumentTextIcon,
  CloudArrowUpIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  ClockIcon,
  BanknotesIcon,
  ChartBarIcon,
  CogIcon,
  WifiIcon,
  NoSymbolIcon
} from '@heroicons/react/24/outline';
import { useOfflineStatus } from '@/lib/offline';
import { notify } from '@/lib/notifications';
import offlineSync from '@/lib/offline/OfflineSync';

// Offline Fiscal Types
interface OfflineInvoice {
  id: string;
  type: 'FACTURA_A' | 'FACTURA_B' | 'FACTURA_C' | 'NOTA_CREDITO' | 'NOTA_DEBITO';
  client: {
    name: string;
    cuit?: string;
    condition: 'RESPONSABLE_INSCRIPTO' | 'MONOTRIBUTO' | 'CONSUMIDOR_FINAL';
  };
  items: Array<{
    description: string;
    quantity: number;
    unitPrice: number;
    taxRate: number;
    total: number;
  }>;
  amounts: {
    subtotal: number;
    ivaAmount: number;
    otherTaxes: number;
    total: number;
  };
  status: 'draft' | 'pending_afip' | 'afip_sent' | 'afip_approved' | 'afip_error';
  timestamp: number;
  syncStatus: 'queued' | 'syncing' | 'synced' | 'failed';
  afipAttempts: number;
  errorMessage?: string;
}

interface FiscalOfflineStats {
  pendingInvoices: number;
  queuedForAfip: number;
  totalAmount: number;
  lastSync: number;
  syncErrors: number;
}

// Mock data for demonstration
const generateMockOfflineInvoices = (): OfflineInvoice[] => [
  {
    id: 'inv_001',
    type: 'FACTURA_C',
    client: {
      name: 'Consumidor Final',
      condition: 'CONSUMIDOR_FINAL'
    },
    items: [
      {
        description: 'Combo Hamburguesa',
        quantity: 2,
        unitPrice: 850,
        taxRate: 21,
        total: 1700
      }
    ],
    amounts: {
      subtotal: 1404.96,
      ivaAmount: 295.04,
      otherTaxes: 0,
      total: 1700
    },
    status: 'pending_afip',
    timestamp: Date.now() - 3600000, // 1 hour ago
    syncStatus: 'queued',
    afipAttempts: 0
  },
  {
    id: 'inv_002',
    type: 'FACTURA_B',
    client: {
      name: 'Restaurant SA',
      cuit: '20-12345678-9',
      condition: 'RESPONSABLE_INSCRIPTO'
    },
    items: [
      {
        description: 'Catering Service',
        quantity: 1,
        unitPrice: 15000,
        taxRate: 21,
        total: 15000
      }
    ],
    amounts: {
      subtotal: 12396.69,
      ivaAmount: 2603.31,
      otherTaxes: 0,
      total: 15000
    },
    status: 'afip_error',
    timestamp: Date.now() - 7200000, // 2 hours ago
    syncStatus: 'failed',
    afipAttempts: 3,
    errorMessage: 'Error de conexión con AFIP - reintentando'
  }
];

export function OfflineFiscalView() {
  const { isOnline, connectionQuality, isSyncing, queueSize } = useOfflineStatus();
  const [activeTab, setActiveTab] = useState('invoices');
  const [offlineInvoices, setOfflineInvoices] = useState<OfflineInvoice[]>([]);
  const [fiscalStats, setFiscalStats] = useState<FiscalOfflineStats | null>(null);
  const [autoSync, setAutoSync] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Initialize offline data
  useEffect(() => {
    // Load from localStorage or generate mock data
    const saved = localStorage.getItem('fiscal_offline_invoices');
    const invoices = saved ? JSON.parse(saved) : generateMockOfflineInvoices();
    setOfflineInvoices(invoices);
    
    // Calculate stats
    const stats: FiscalOfflineStats = {
      pendingInvoices: invoices.filter(inv => inv.status === 'pending_afip').length,
      queuedForAfip: invoices.filter(inv => inv.syncStatus === 'queued').length,
      totalAmount: invoices.reduce((sum, inv) => sum + inv.amounts.total, 0),
      lastSync: Date.now() - 900000, // 15 minutes ago
      syncErrors: invoices.filter(inv => inv.syncStatus === 'failed').length
    };
    setFiscalStats(stats);
  }, []);

  // Handle invoice sync
  const handleSyncInvoice = useCallback(async (invoice: OfflineInvoice) => {
    try {
      // Mark as syncing
      setOfflineInvoices(prev => 
        prev.map(inv => 
          inv.id === invoice.id 
            ? { ...inv, syncStatus: 'syncing' }
            : inv
        )
      );

      // Queue the invoice for sync using OfflineSync
      await offlineSync.queueOperation({
        type: 'CREATE',
        entity: 'fiscal_invoice',
        data: invoice,
        priority: 1 // High priority for fiscal operations
      });

      // Update status
      setOfflineInvoices(prev => 
        prev.map(inv => 
          inv.id === invoice.id 
            ? { ...inv, syncStatus: 'queued', status: 'afip_sent' }
            : inv
        )
      );

      notify.success(`Invoice ${invoice.id} queued for AFIP sync`);
    } catch (error) {
      // Mark as failed
      setOfflineInvoices(prev => 
        prev.map(inv => 
          inv.id === invoice.id 
            ? { ...inv, syncStatus: 'failed', afipAttempts: inv.afipAttempts + 1 }
            : inv
        )
      );
      
      notify.error(`Failed to queue invoice ${invoice.id}: ${error.message}`);
    }
  }, []);

  // Bulk sync all pending invoices
  const handleBulkSync = useCallback(async () => {
    const pendingInvoices = offlineInvoices.filter(
      inv => inv.syncStatus === 'queued' || inv.syncStatus === 'failed'
    );

    if (pendingInvoices.length === 0) {
      notify.info('No invoices pending sync');
      return;
    }

    notify.info(`Starting bulk sync of ${pendingInvoices.length} invoices`);
    
    for (const invoice of pendingInvoices) {
      await handleSyncInvoice(invoice);
      // Small delay to prevent overwhelming the sync queue
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }, [offlineInvoices, handleSyncInvoice]);

  // Force manual fiscal sync
  const handleForceFiscalSync = useCallback(async () => {
    try {
      await offlineSync.forcSync();
      notify.success('Fiscal data sync initiated');
    } catch (error) {
      notify.error('Failed to initiate fiscal sync');
    }
  }, []);

  const getStatusBadgeProps = (status: OfflineInvoice['status']) => {
    switch (status) {
      case 'draft':
        return { colorScheme: 'gray', label: 'Borrador' };
      case 'pending_afip':
        return { colorScheme: 'yellow', label: 'Pendiente AFIP' };
      case 'afip_sent':
        return { colorScheme: 'blue', label: 'Enviado AFIP' };
      case 'afip_approved':
        return { colorScheme: 'green', label: 'AFIP Aprobado' };
      case 'afip_error':
        return { colorScheme: 'red', label: 'Error AFIP' };
      default:
        return { colorScheme: 'gray', label: 'Desconocido' };
    }
  };

  const getSyncStatusBadgeProps = (syncStatus: OfflineInvoice['syncStatus']) => {
    switch (syncStatus) {
      case 'queued':
        return { colorScheme: 'yellow', label: 'En Cola' };
      case 'syncing':
        return { colorScheme: 'blue', label: 'Sincronizando' };
      case 'synced':
        return { colorScheme: 'green', label: 'Sincronizado' };
      case 'failed':
        return { colorScheme: 'red', label: 'Error' };
      default:
        return { colorScheme: 'gray', label: 'Pendiente' };
    }
  };

  return (
    <Box>
      {/* Offline Status Header */}
      <Card mb={6} p={4}>
        <HStack justify="space-between" align="center">
          <HStack spacing={4}>
            <Badge 
              colorPalette={isOnline ? 'green' : 'orange'} 
              p={2}
              variant="subtle"
            >
              <HStack spacing={1}>
                {isOnline ? (
                  <WifiIcon className="w-4 h-4" />
                ) : (
                  <NoSymbolIcon className="w-4 h-4" />
                )}
                <Text fontSize="sm" fontWeight="medium">
                  {isOnline ? 'Modo Online' : 'Modo Offline'}
                </Text>
              </HStack>
            </Badge>

            <Text fontSize="sm" color="gray.600">
              Sistema fiscal funcionando offline. Las facturas se sincronizarán automáticamente.
            </Text>

            {isSyncing && (
              <Badge colorPalette="blue" size="sm">
                <HStack spacing={1}>
                  <CloudArrowUpIcon className="w-3 h-3" />
                  <Text fontSize="xs">Sincronizando ({queueSize})</Text>
                </HStack>
              </Badge>
            )}
          </HStack>

          <HStack spacing={2}>
            <Switch
              checked={autoSync}
              onCheckedChange={(e) => setAutoSync(e.checked)}
              size="sm"
            >
              <Text fontSize="sm">Auto-sync</Text>
            </Switch>
            
            <Button
              size="sm"
              colorPalette="blue"
              onClick={handleBulkSync}
              leftIcon={<CloudArrowUpIcon className="w-4 h-4" />}
            >
              Sync AFIP
            </Button>
          </HStack>
        </HStack>
      </Card>

      {/* Offline Fiscal Stats */}
      {fiscalStats && (
        <SimpleGrid columns={{ base: 2, md: 4 }} gap={4} mb={6}>
          <Card p={4}>
            <Stat.Root>
              <Stat.Label fontSize="sm">Facturas Pendientes</Stat.Label>
              <Stat.ValueText fontSize="2xl" color="yellow.500">
                {fiscalStats.pendingInvoices}
              </Stat.ValueText>
              <Stat.HelpText fontSize="xs">
                <DocumentTextIcon className="w-3 h-3 inline mr-1" />
                Esperando AFIP
              </Stat.HelpText>
            </Stat.Root>
          </Card>

          <Card p={4}>
            <Stat.Root>
              <Stat.Label fontSize="sm">En Cola Sync</Stat.Label>
              <Stat.ValueText fontSize="2xl" color="blue.500">
                {fiscalStats.queuedForAfip}
              </Stat.ValueText>
              <Stat.HelpText fontSize="xs">
                <ClockIcon className="w-3 h-3 inline mr-1" />
                Para sincronizar
              </Stat.HelpText>
            </Stat.Root>
          </Card>

          <Card p={4}>
            <Stat.Root>
              <Stat.Label fontSize="sm">Total Offline</Stat.Label>
              <Stat.ValueText fontSize="2xl" color="green.500">
                ${fiscalStats.totalAmount.toLocaleString()}
              </Stat.ValueText>
              <Stat.HelpText fontSize="xs">
                <BanknotesIcon className="w-3 h-3 inline mr-1" />
                Monto acumulado
              </Stat.HelpText>
            </Stat.Root>
          </Card>

          <Card p={4}>
            <Stat.Root>
              <Stat.Label fontSize="sm">Errores Sync</Stat.Label>
              <Stat.ValueText fontSize="2xl" color={fiscalStats.syncErrors > 0 ? "red.500" : "gray.500"}>
                {fiscalStats.syncErrors}
              </Stat.ValueText>
              <Stat.HelpText fontSize="xs">
                <ExclamationTriangleIcon className="w-3 h-3 inline mr-1" />
                Requieren atención
              </Stat.HelpText>
            </Stat.Root>
          </Card>
        </SimpleGrid>
      )}

      {/* Connection Warning */}
      {!isOnline && (
        <Alert status="warning" mb={4}>
          <Alert.Indicator />
          <Box>
            <Alert.Title>Funcionando Offline</Alert.Title>
            <Alert.Description>
              Las facturas se están generando localmente y se sincronizarán con AFIP cuando se restaure la conexión.
              Todas las operaciones fiscales están siendo guardadas de forma segura.
            </Alert.Description>
          </Box>
        </Alert>
      )}

      {/* Sync Progress */}
      {isSyncing && (
        <Card mb={4} p={4} bg="blue.50" borderColor="blue.200" borderWidth="1px">
          <VStack spacing={3}>
            <HStack justify="space-between" w="full">
              <Text fontSize="sm" fontWeight="medium" color="blue.700">
                Sincronizando datos fiscales con AFIP...
              </Text>
              <Badge colorPalette="blue" size="sm">{queueSize} operaciones</Badge>
            </HStack>
            <Progress.Root value={75} size="sm" colorPalette="blue" w="full">
              <Progress.Track>
                <Progress.Range />
              </Progress.Track>
            </Progress.Root>
            <Text fontSize="xs" color="blue.600">
              Sincronización automática en progreso. No cerrar la aplicación.
            </Text>
          </VStack>
        </Card>
      )}

      {/* Offline Invoice Management */}
      <Card p={6}>
        <VStack spacing={6} align="stretch">
          <HStack justify="space-between">
            <Text fontSize="lg" fontWeight="semibold">Gestión Fiscal Offline</Text>
            <HStack>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowAdvanced(!showAdvanced)}
                leftIcon={<CogIcon className="w-4 h-4" />}
              >
                {showAdvanced ? 'Ocultar' : 'Avanzado'}
              </Button>
              <Button
                size="sm"
                colorPalette="blue"
                onClick={handleForceFiscalSync}
                leftIcon={<CloudArrowUpIcon className="w-4 h-4" />}
                loading={isSyncing}
              >
                Forzar Sync
              </Button>
            </HStack>
          </HStack>

          {/* Invoice List */}
          <VStack spacing={3} align="stretch">
            {offlineInvoices.map((invoice) => {
              const statusProps = getStatusBadgeProps(invoice.status);
              const syncProps = getSyncStatusBadgeProps(invoice.syncStatus);
              
              return (
                <Card key={invoice.id} p={4} variant="outline">
                  <HStack justify="space-between">
                    <VStack align="start" spacing={2}>
                      <HStack spacing={3}>
                        <Text fontWeight="medium">{invoice.id}</Text>
                        <Badge colorPalette={statusProps.colorScheme} size="sm">
                          {statusProps.label}
                        </Badge>
                        <Badge colorPalette={syncProps.colorScheme} size="sm">
                          {syncProps.label}
                        </Badge>
                      </HStack>
                      
                      <HStack spacing={4} fontSize="sm" color="gray.600">
                        <Text>{invoice.client.name}</Text>
                        <Text>•</Text>
                        <Text>{invoice.type}</Text>
                        <Text>•</Text>
                        <Text>${invoice.amounts.total.toLocaleString()}</Text>
                        <Text>•</Text>
                        <Text>{new Date(invoice.timestamp).toLocaleString()}</Text>
                      </HStack>

                      {invoice.errorMessage && (
                        <Text fontSize="xs" color="red.500">
                          {invoice.errorMessage}
                        </Text>
                      )}

                      {showAdvanced && (
                        <VStack align="start" spacing={1} fontSize="xs" color="gray.500">
                          <Text>Subtotal: ${invoice.amounts.subtotal.toFixed(2)}</Text>
                          <Text>IVA: ${invoice.amounts.ivaAmount.toFixed(2)}</Text>
                          <Text>Intentos AFIP: {invoice.afipAttempts}</Text>
                        </VStack>
                      )}
                    </VStack>

                    <VStack spacing={2}>
                      {invoice.syncStatus === 'failed' && (
                        <Tooltip label="Reintentar sincronización con AFIP">
                          <Button
                            size="xs"
                            colorPalette="orange"
                            onClick={() => handleSyncInvoice(invoice)}
                            leftIcon={<CloudArrowUpIcon className="w-3 h-3" />}
                          >
                            Reintentar
                          </Button>
                        </Tooltip>
                      )}

                      {invoice.syncStatus === 'queued' && (
                        <Badge colorPalette="yellow" size="sm">
                          <ClockIcon className="w-3 h-3 mr-1" />
                          Esperando
                        </Badge>
                      )}

                      {invoice.status === 'afip_approved' && (
                        <Badge colorPalette="green" size="sm">
                          <CheckCircleIcon className="w-3 h-3 mr-1" />
                          Completado
                        </Badge>
                      )}
                    </VStack>
                  </HStack>
                </Card>
              );
            })}
          </VStack>

          {offlineInvoices.length === 0 && (
            <Box textAlign="center" py={8} color="gray.500">
              <DocumentTextIcon className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <Text>No hay facturas offline disponibles</Text>
              <Text fontSize="sm">Las facturas aparecerán aquí cuando se generen sin conexión</Text>
            </Box>
          )}
        </VStack>
      </Card>
    </Box>
  );
}

export default OfflineFiscalView;