export { default as FiscalPage } from './FiscalPage';
export * from './types';
export * from './logic/useFiscal';
export * from './data/fiscalApi';