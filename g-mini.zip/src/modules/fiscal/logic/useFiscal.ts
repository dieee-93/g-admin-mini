import { useState, useEffect } from 'react';
import { fiscalApi } from '../data/fiscalApi';
import { type FiscalStats } from '../types';

interface UseFiscalReturn {
  fiscalStats: FiscalStats | null;
  isLoading: boolean;
  error: string | null;
  refreshStats: () => Promise<void>;
}

export function useFiscal(): UseFiscalReturn {
  const [fiscalStats, setFiscalStats] = useState<FiscalStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchFiscalStats = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const stats = await fiscalApi.getFiscalStats();
      setFiscalStats(stats);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al cargar estadísticas fiscales');
      console.error('Error fetching fiscal stats:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshStats = async () => {
    await fetchFiscalStats();
  };

  useEffect(() => {
    fetchFiscalStats();
  }, []);

  return {
    fiscalStats,
    isLoading,
    error,
    refreshStats
  };
}