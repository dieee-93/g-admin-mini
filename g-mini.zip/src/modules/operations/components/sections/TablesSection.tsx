// Tables Section - Integrated Table Management Page
import React from "react";
import { TableManagementPage } from "../tables/TableManagementPage";

export function TablesSection() {
  return <TableManagementPage />;
}
