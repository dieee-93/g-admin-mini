// ABC Analysis - Advanced inventory classification and optimization
export { default as default } from './ABCAnalysisPage';
export * from './types';