// Business Analytics - Cross-module analytics and strategic insights
export { default as default } from './BusinessAnalyticsPage';
export * from './types';