import { Card } from '@chakra-ui/react'
import React, { ReactNode } from 'react'

interface CardWrapperProps {
  children: ReactNode
  variant?: 'elevated' | 'outline' | 'subtle' | 'filled' | 'ghost'
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  colorPalette?: string
  className?: string
  [key: string]: any
}

interface CardHeaderProps {
  children: ReactNode
  className?: string
  [key: string]: any
}

interface CardBodyProps {
  children: ReactNode
  className?: string
  [key: string]: any
}

interface CardFooterProps {
  children: ReactNode
  className?: string
  [key: string]: any
}

// ✅ Estructura correcta según documentación oficial Chakra UI v3
function CardWrapper({ children, ...props }: CardWrapperProps) {
  return (
    <Card.Root {...props}>
      {children}
    </Card.Root>
  )
}

function CardHeader({ children, ...props }: CardHeaderProps) {
  return (
    <Card.Header {...props}>
      {children}
    </Card.Header>
  )
}

function CardBody({ children, ...props }: CardBodyProps) {
  return (
    <Card.Body {...props}>
      {children}
    </Card.Body>
  )
}

function CardFooter({ children, ...props }: CardFooterProps) {
  return (
    <Card.Footer {...props}>
      {children}
    </Card.Footer>
  )
}

// Compound component pattern
CardWrapper.Header = CardHeader
CardWrapper.Body = CardBody
CardWrapper.Footer = CardFooter

// Export all components
export { CardWrapper, CardHeader, CardBody, CardFooter }